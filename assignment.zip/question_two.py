#Question 2: Implement a basic measure of tracking the space used by an algorithm

from memory_profiler import profile

@profile # function decorator to track it's space process after process
def sorting():
    list = []
    # number of elements as input
    n = int(input("Enter number element: "))
    print("enter the values of the list")
    # iterating till the range
    for i in range(0, n):
        element = int(input())

        list.append(element)  # adding the element
    print("the list is:", list)  # display the list

    list.sort()
    print("the sorted list is:", list)  # display sorted list

sorting() # function call

