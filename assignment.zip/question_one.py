import time

b = "I am grateful!!"
print(b)

# starting time
start = time.time()
for i in range(0):
    print(i)
time.sleep(1)
end = time.time()

# total time taken
print(f"Runtime of the program is {end - start}")
