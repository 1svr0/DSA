# question 3:
# part ii : Make each letter in a string lowercase

word = print(input("Enter your word: ").lower()) #user input their word .lower() will change the string to lowercase
print(word) #print the string in lowercase