import time

start = time.time()
word = print(input("Enter your word: ").lower())
print(word)
end= time.time()
run= end-start
print(run * 1000000)