# question 3:
# part ii : Make each letter in a string lowercase

word = print(input("Enter your word: ").lower())
print(word)