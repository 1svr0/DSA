import time

list = []
# number of elements as input
n = int(input("Enter number element: "))
print("enter the values of the list")
# iterating till the range
start = time.time()
for i in range(0, n):
    element = int(input())

    list.append(element)  # adding the element
end = time.time()
print("the list is:", list)
maximum = max(list)
print("the maximum value in the list is:", maximum)
print(end-start)
