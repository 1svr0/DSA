# question 3:
# part iii : Sort a list of integers (using the inbuilt python method)

list = []
# number of elements as input
n = int(input("Enter number element: "))
print("enter the values of the list")
# iterating till the range
for i in range(0, n):
    element = int(input())

    list.append(element)  # adding the element
print("the list is:", list)

list.sort()
print("the sorted list is:", list)
