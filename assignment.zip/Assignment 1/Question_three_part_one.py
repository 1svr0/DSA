# question 3:
# part i : Find the maximum value in a list
import time
list = []
# number of elements as input
n = int(input("Enter number element: "))
print("enter the values of the list")
# iterating till the range
start = time.time()
for i in range(0, n):
    element = int(input())

    list.append(element)  # adding the element

print("the list is:", list)
maximum = max(list)
print("the maximum is:", maximum)
end = time.time()
# print("the maximum value in the list is:", maximum)

#return maximum, end-start