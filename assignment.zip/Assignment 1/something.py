import time
def maxi():
    list = []
    start=time.time()
    # number of elements as input
    n = int(input("Enter number element: "))
    print("enter the values of the list")
    # iterating till the range
    for i in range(0, n):
        element = int(input())

        list.append(element)  # adding the element

    print("the list is:", list)
    maximum= max(list)
    end=time.time()
    return maximum, end-start

def letter():
    start=time.time()
    word = print(input("Enter your word: "))
    end=time.time()
    return word.lower(), end-start

def sortlist():
    start=time.time()
    list = []
    # number of elements as input
    n = int(input("Enter number element: "))
    print("enter the values of the list")
    # iterating till the range
    for i in range(0, n):
        element = int(input())

        list.append(element)  # adding the element
    print("the list is:", list)
    end= time.time()
    return list.sort(), end-start
