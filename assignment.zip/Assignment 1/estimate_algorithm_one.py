# question 5: Estimate how long each algorithm would take
# part i : Finding the maximum value in a list

import time

from five import end, start
from Question_three_part_one import maximum


def maxCheck(x):
    start = time.time()
    list = []
    # number of elements as input
    n = int(input("Enter number element: "))
    print("enter the values of the list")
    # iterating till the range
    for i in range(0, n):
        element = int(input())

        list.append(element)  # adding the element

    print("the list is:", list)
    maximum = max(list)

    end = time.time()
    return maximum, end-start