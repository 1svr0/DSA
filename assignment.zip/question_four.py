import matplotlib.pyplot as plt



# Question 1 points
number_inputs = [23, 43, 54]
space_complexity = [23, 19.3, 20]
# plotting the question 1 points on line 1
plt.plot(number_inputs, space_complexity, label="Algorithm of Maximum Number")

# Question 2 points
number_inputs = [12,34,89]
space_complexity = [19.3,19.4,19.5]
# plotting the question 2 points on line 2
plt.plot(number_inputs, space_complexity, label="Algorithm of String Case")

# Question 3 points
number_inputs = [18,54,79]
space_complexity = [19.4,19.2,19.5]
# plotting the question 3 points on line 3
plt.plot(number_inputs, space_complexity, label="Algorithm of List sort")

#The X axis
plt.xlabel('X - axis')
# The Y axis
plt.ylabel('Y - axis')
# Graph's title
plt.title('Graph of Time against Space!')

# Function for showing a legend on the plot
plt.legend()

# The function for showing the plot
plt.show()